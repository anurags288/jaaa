package P2;
import java.io.*;
import P1.*;
class rational
	{
	private int num;
	private int den;
	rational()
		{
		num=0;
		den=1;
		}
	rational(int n,int d)
		{
		num=n;
		den=d;
		}
	rational add(rational ob)
		{
		rational obj=new rational();
		obj.num=(num*ob.den)+(ob.num*den);
		obj.den=(den*ob.den);
		return obj;
		}
	rational substract(rational ob)
		{
		rational obj=new rational();
		obj.num=(num*ob.den)-(ob.num*den);
		obj.den=(den*ob.den);
		return obj;
		}
	rational multiply(rational ob)
		{
		rational obj=new rational();
		obj.num=num*ob.num;
		obj.den=(den*ob.den);
		return obj;
		}
	rational divide(rational ob)
		{
		rational obj=new rational();
		obj.num=num*ob.den;
		obj.den=(den*ob.num);
		return obj;
		}
	void display()
		{
		System.out.println("Fraction is="+num+"/"+den+"\n");
		}
	rational convert()
		{
		P1.GCD temp=new GCD();
		int r=temp.gcd(num,den);
		rational obj=new rational();
		obj.num=num/r;
		obj.den=den/r;
		return obj;
		}
	}


class rational1
	{
	public static void main(String[] args)throws IOException
		{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter numerator 1");
		int n1=Integer.parseInt(br.readLine());
		System.out.println("Enter denominator 1");
		int d1=Integer.parseInt(br.readLine());
		System.out.println("Enter numerator 2");
		int n2=Integer.parseInt(br.readLine());
		System.out.println("Enter denominator 2");
		int d2=Integer.parseInt(br.readLine());
		rational f1=new rational(n1,d1);
		rational f2=new rational(n2,d2);
		int f=0;
		while (f==0)
			{
			System.out.println("1------> Add two fractions");
			System.out.println("2------> Substract two fractions");
			System.out.println("3------> Multiply two fractions");
			System.out.println("4------> Divide two fractions");	
			System.out.println("5------> Exit");
			System.out.println("Enter choice");
			int ch=Integer.parseInt(br.readLine());
			switch(ch)
				{
				case 1:
				rational a;
				a=f1.add(f2);
				rational j;
				j=a.convert();
				System.out.println("Addition of two fractions is \n");
				j.display();
				break;
				case 2:
				rational ab;
				ab=f1.substract(f2);
				rational k;
				k=ab.convert();
				System.out.println("Substraction of two fractions is \n");
				k.display();
				break;
				case 3:
				rational ac;
				ac=f1.multiply(f2);
				rational u;
				u=ac.convert();
				System.out.println("Multiplication of two fractions is \n");
				u.display();
				break;
				case 4:
				rational ad;
				ad=f1.divide(f2);
				rational w;
				w=ad.convert();
				System.out.println("Division of two fractions is \n");
				w.display();
				break;
				case 5:
				f=1;
				System.out.println("Invalid choice");
				break;
				}
			}
		}
	}

