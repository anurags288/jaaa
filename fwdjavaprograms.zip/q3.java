import java.io.*;
class q3
	{
	void factorial(int n)
		{
		int fact=0;
		for(int i=n;i>0;i++)
			{
			fact=fact*i;
			}
		System.out.println("Factorial ="+fact);
		}
	void gcd(int a,int b)
		{
		int r=0;
		while(b != 0)
			{
			r = a%b;
			a=b;
			b= r;
			}
		System.out.print("GCD = "+a);
		}
	void fibonacci(int k)
		{
		System.out.println("Fibonacci series is");
		int a=0,b=1,c;
		System.out.print(a+" "+b);
		for(int i=2;i<k;i++)
			{
			c=a+b;
			System.out.print(" "+c);
			a=b;
			b=c;
			}
		}
	}

class demoq3 
	{
	public static void main(String args[])throws IOException
		{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int r=Integer.parseInt(args[0]);
		System.out.println("Enter choice between 1,2,3");
		int c=Integer.parseInt(br.readLine());
		q3 ob=new q3();
		switch(c)
			{
			case 1:
			System.out.println("Enter number for factorial");
			int y=Integer.parseInt(br.readLine());
			ob.factorial(y);
			break;
			case 2:
			System.out.println("Enter numbers for gcd");
			int s=Integer.parseInt(br.readLine());
			int q=Integer.parseInt(br.readLine());
			ob.gcd(s,q);
			break;
			case 3:
			System.out.println("Enter number of terms for fibonacci");
			int z=Integer.parseInt(br.readLine());
			ob.fibonacci(z);
			break;
			default:
			System.out.println("Invalid choice");
			break;
			}
		}
	}

