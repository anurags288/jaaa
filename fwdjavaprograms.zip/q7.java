import java.io.*;
class complex
	{
	double real,imaginary;
	complex()
		{
		real=0.0;
		imaginary=0.0;
		}	
	complex(double r,double im)
		{
		real=r;
		imaginary=im;
		}
	complex add(complex c)
		{
		complex ob=new complex();
		ob.real=real+c.real;
		ob.imaginary=imaginary+c.imaginary;
		return ob;
		}
	complex substract(complex c)
		{
		complex ob=new complex();
		ob.real=real-c.real;
		ob.imaginary=imaginary-c.imaginary;
		return ob;
		}
	complex multiply(complex c)
		{
		complex obj=new complex();
		obj.real=(real*c.real)-(imaginary*c.imaginary);
		obj.imaginary=(real*c.imaginary)+(c.real*imaginary);
		return obj;
		}
	public String toString()
		{
		return real+""+imaginary+"i";
		}
	}

class demoq7
	{
	public static void main(String args[])throws IOException
		{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter real number 1");
		double r1=Double.parseDouble(br.readLine());
		System.out.println("Enter imaginary number 1");
		double im1=Double.parseDouble(br.readLine());
		complex object1=new complex(r1,im1);
		System.out.println("Enter real number 2");
		double r2=Double.parseDouble(br.readLine());
		System.out.println("Enter imaginary number 2");
		double im2=Double.parseDouble(br.readLine());
		complex object2=new complex(r2,im2);		
		int f=0;		
		while (f==0)		
			{
			System.out.println("1----->Add two complex numbers");
			System.out.println("2----->Substract two complex numbers");
			System.out.println("3----->multiply two complex numbers");
			System.out.println("4----->Exit");
			int ch=Integer.parseInt(br.readLine());
			switch(ch)
				{
				case 1:
				complex p=object1.add(object2);
				System.out.println("Addition is");
				System.out.println(p);
				break;
				case 2:		
				complex q=object1.substract(object2);
				System.out.println("Substraction is");
				System.out.println(q);
				break;
				case 3:		
				complex r=object1.multiply(object2);
				System.out.println("Multiplication is");
				System.out.println(r);
				break;
				case 4:
				f=1;
				break;				
				default:
				System.out.println("invalid choice");	
				}
			}
		}
	}
		
