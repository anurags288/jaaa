import java.io.*;
class box
	{
	double length,breadth,height;
 	box()
		{	
		length=0.0;
		breadth=0.0;
		height=0.0;
		}
	box(double l,double b,double h)
		{
		length=l;
		breadth=b;
		height=h;
		}
	void surface_area()
		{
		System.out.println("Surface area="+(2*((length*breadth)+(breadth*height)+(height*length))));
		}
	void volume()
		{
		System.out.println("Volume="+(length*breadth*height));
		}
	public String toString()
		{
		return "Dimensions of box are: \n Length="+length+"\t Breadth="+breadth+"\t Height="+height;
		}
	}

class demoq8
	{
	public static void main(String args[])throws IOException
		{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter length");
		double p=Double.parseDouble(br.readLine());
		System.out.println("Enter breadth");
		double q=Double.parseDouble(br.readLine());
		System.out.println("Enter height");
		double r=Double.parseDouble(br.readLine());
		box ob=new box();
		System.out.print(ob);
		ob.surface_area();
		ob.volume();
		box obj=new box(p,q,r);
		System.out.print(obj);
		obj.surface_area();
		obj.volume();
		}
	}

