import java.io.*;
class q4
{
void prime(int n)
{
int num, count, i;
    num=1;
    count=0;
 
    while (count < n)
	{
      num=num+1;
      for (i = 2; i <= num; i++)
	{
        if (num % i == 0) 
	{
          break;
        }
      }
      if ( i == num)
	{
        count = count+1;
      }
    }
    System.out.println("Value of nth prime: " + num);
}
}

class demoq4
{
public static void main(String args[])throws IOException
{
int a;
if(args[]!=null)
{
a=Integer.parseInt(args[0]);
}
else
{
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
System.out.println("Enter a number");
a=Integer.parseInt(br.readLine());
}
q4 ob=new q4();
ob.prime(a);
}
}

