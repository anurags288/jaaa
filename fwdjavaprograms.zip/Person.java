package P1;
import java.io.*;
public class Person
	{
	public String name;	
	public String father_name;
	public int age;
	public String dob;
	public Person(String n,String f,String d,int a)
		{
		name=n;
		father_name=f;
		age=a;
		dob=d;
		}
	public String toString()
		{
		return "\n Name::"+name+"\n Father's Name::"+father_name+"\n Age::"+age+"\n Date of Birth::"+dob;
		}
	}
