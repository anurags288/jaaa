import java.io.*;
abstract class Shape
	{
	abstract void area();
	}

class Rectangle extends Shape
	{
	double length;
	double breadth;
	Rectangle(double l,double b)
		{
		length=l;
		breadth=b;
		}
	void area()
		{
		System.out.println("Area of rectangle is   "+(length*breadth));
		}
	}

class Circle extends Shape
	{
	double radius;
	Circle(double r)
		{
		radius=r;
		}
	void area()
		{
		double s=(22/7)*Math.pow(radius,2);
		System.out.println("Area of circle is   "+s);
		}
	}
	
class demoq14
	{
	public static void main(String argc[])throws IOException
		{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int f=0;
		while(f==0)		
			{
			System.out.println("1--------> Area of rectangle");
			System.out.println("2--------> Area of circle");
			System.out.println("3--------> Exit");
			int ch=Integer.parseInt(br.readLine());
			switch (ch)
				{
				case 1:
				System.out.println("Enter length");
				double n=Double.parseDouble(br.readLine());
				System.out.println("Enter breadth");
				double m=Double.parseDouble(br.readLine());
				Rectangle q=new Rectangle(n,m);
				Shape S;
				S=q;
				S.area();
				break;
				case 2:
				System.out.println("Enter radius");
				double r=Double.parseDouble(br.readLine());
				Circle w=new Circle(r);
				Shape T;
				T=w;
				T.area();
				break;
				case 3:
				System.out.println("Invalid choice");
				f=1;
				break;
				}
			}
		}
	}

