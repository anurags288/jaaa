package P2;
import java.io.*;
import P1.*;
public class even
	{
	public int sum_even(int n)
		{
		int s=0;
		int j=-2;
	 	for(int i=0;i<n;i++)
			{
			j=j+2;
			s=s+j;
			}
		return s;
		}
	}

class demoven
	{
	public static void main(String args[])throws IOException
		{
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		int r;
		System.out.println("Enter the number of element");
		r=Integer.parseInt(br.readLine());
		int f=0;
		while(f==0)
			{
			System.out.println("Enter 1 -------> odd");
			System.out.println("Enter 2 -------> even");
			System.out.println("Enter 3 -------> exit");
			int c=Integer.parseInt(br.readLine());
			switch (c)
				{
				case 1:
				P1.odd o= new odd();
				int m=o.sum_odd(r);
				System.out.println("Sum of odd = "+m);
				break;
				case 2:
				even e= new even();
				int y=e.sum_even(r);
				System.out.println("Sum of even = "+y);
				break;
				case 3:
				f=1;
				System.out.println("Invalid choice");
				break;
				}
			}
		}
	}

		
