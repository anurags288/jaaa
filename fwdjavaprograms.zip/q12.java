class q12
	{
	double area(double r)
		{
		return ((22/7)*(r*r));
		}
	double area(double a,double b)
		{
		return (a*b);
		}
	double area(double s1,double s2,double s3)
		{
		double s=(s1+s2+s3)/3;
		double a=Math.sqrt(s*(s-s1)*(s-s2)*(s-s3));
		return a;
		}
	void show(double q)
		{
		System.out.println(q);
		}
	}
	

class demoq12
	{
	public static void main(String args[])
		{
		int c=Integer.parseInt(args[0]);
		switch (c)
			{	
			case 1:
			q12 ob=new q12();
			double r=Integer.parseInt(args[1]);
			double a1=ob.area(r);
			System.out.println("Area of circle is");
			ob.show(a1);
			break;
			case 2:
			q12 obj=new q12();
			double a=Integer.parseInt(args[1]);
			double b=Integer.parseInt(args[2]);
			double a2=obj.area(a,b);
			System.out.println("Area of rectangle is");
			obj.show(a2);
			break;
			case 3:
			q12 obje=new q12();
			double s1=Integer.parseInt(args[1]);
			double s2=Integer.parseInt(args[2]);
			double s3=Integer.parseInt(args[3]);
			double a3=obje.area(s1,s2,s3);
			System.out.println("area of triangle is");
 			obje.show(a3);
			break;
			case 4:
			System.out.println("Invalid choice");
			}
		}
	}

