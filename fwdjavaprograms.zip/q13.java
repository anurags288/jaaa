import java.io.*;
class TwoDim
	{
	int x;
	int y;
	TwoDim()
		{
		x=0;
		y=0;
		}
	TwoDim(int xx,int yy)
		{
		x=xx;
		y=yy;
		}
	void print()
		{
		System.out.println("The coordinates are"+x+"x+"+y+"y");
		}
	}

class ThreeDim extends TwoDim
	{
	int z;
	ThreeDim()
		{
		super();
		z=0;
		}
	ThreeDim(int a,int b,int c)
		{
		super(a,b);
		z=c;
		}
	void print()
		{
		System.out.println("The coordinates are"+x+"x+"+y+"y+"+z+"z");
		}
	}
class demoq13
	{
	public static void main(String args[])throws IOException
		{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter first coordinate");
		int p=Integer.parseInt(br.readLine());
		System.out.println("Enter second coordinate");
		int q=Integer.parseInt(br.readLine());
		System.out.println("Enter third coordinate");
		int r=Integer.parseInt(br.readLine());
		ThreeDim temp=new ThreeDim(p,q,r);
		TwoDim f;
		f=temp;
		f.print();
		}
	}

		
