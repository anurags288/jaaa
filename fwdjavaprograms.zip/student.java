package P2;
import P1.*;
import java.io.*;
class student extends P1.Person
	{
	int roll_no;
	int Class;
	int marks_obt;
	student(int r,int c,int m,String n,String f,String d,int a)
		{
		super(n,f,d,a);
		roll_no=r;
		Class=c;
		marks_obt=m;
		}
	public String toString()		
		{
		
		return "\n Roll number::"+roll_no+"\n Class::"+Class+"\n Marks Obtained::"+marks_obt;
		}
	}
	
class demostudent 
	{
	public static void main(String args[])throws IOException
		{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter name");
		String n=br.readLine(); 
		System.out.println("Enter father's name");
		String f=br.readLine();
		System.out.println("Enter date of birth in words");
		String d=br.readLine();
		System.out.println("Enter age");
		int a=Integer.parseInt(br.readLine());		
		System.out.println("Enter Roll number");
		int r=Integer.parseInt(br.readLine());
		System.out.println("Enter Class");
		int c=Integer.parseInt(br.readLine());
		System.out.println("Enter Marks Obtained");
		int m=Integer.parseInt(br.readLine());
		Person p= new Person(n,f,d,a);
		System.out.println(p);
		student s=new student(r,c,m,n,f,d,a);
		System.out.println(s);
		}
	}

