import java.io.*;
class q2
	{
	public static void main(String args[])throws IOException
		{
		int sum=0;
		BufferedReader X=new BufferedReader(new InputStreamReader(System.in));
		int n=Integer.parseInt(args[0]);
		for(int i=0;i<n;i++)
			{
			System.out.println("enter element");
			int r=Integer.parseInt(X.readLine());
			sum=sum+r;
			}
		System.out.println("Sum="+sum);
		}
	}


