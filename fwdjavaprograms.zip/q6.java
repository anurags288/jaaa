import java.io.*;
class q6
	{
	int n;
	int ar[];
	q6(int nn)
		{
		n=nn;
		ar=new int[n];
		}
	void input(int arr[])
		{
		for(int i=0;i<n;i++)
			{
			ar[i]=arr[i];
			}
		}
	void even()
		{
		System.out.println("Even valued elements are");
		for(int i=0;i<n;i++)
			{
			if(ar[i]%2==0)
				{
				System.out.println(ar[i]);
				}
			}
		}
	void odd()
		{
		System.out.println("odd valued elements are");
		for(int i=0;i<n;i++)
			{
			if(ar[i]%2!=0)
				{
				System.out.println(ar[i]);
				}
			}
		}
	void sum_avg()
		{
		int sum=0;
		double avg=0.0;
		for(int i=0;i<n;i++)
			{
			sum=sum+ar[i];
			}
		avg=sum/n;
		System.out.println("Sum="+sum);
		System.out.println("Average="+avg);
		}
	void reverse()
		{
		System.out.println("Array in reverse is");
		for(int i=n-1;i>=0;i--)int arr[])
			{
			System.out.println(ar[i]);
			}
		}
	}

class demoq6
	{
	public static void main(String args[])throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter size of the array");
		int o=Integer.parseInt(br.readLine());
		int arr[]=new int[o];
		for(int i=0;i<o;i++)
			{
			System.out.println("Enter elements in the array");
			arr[i]=Integer.parseInt(br.readLine());
			}
		q6 ob=new q6(o);
		ob.input(arr);
		int f=0;		
		while (f==0)		
		{
			System.out.println("1----->Even elements");
			System.out.println("2----->Odd elements");
			System.out.println("3----->Sum and average");
			System.out.println("4----->Array in reverse order");
			System.out.println("5----->Exit");
			int ch=Integer.parseInt(br.readLine());
			switch(ch)
			{
				case 1:
				ob.even();
				break;
				case 2:		
				ob.odd();
				break;
				case 3:		
				ob.sum_avg();
				break;
				case 4:
				ob.reverse();
				break;
				case 5:
				f=1;
				break;				
				default:
				System.out.println("invalid choice");	
			}
		}
	}
}
		
