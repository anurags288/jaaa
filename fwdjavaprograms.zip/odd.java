package P1;
public class odd
	{
	public int sum_odd(int n)
		{
		int s=0;
		int j=-1;
	 	for(int i=0;i<n;i++)
			{
			j=j+2;
			s=s+j;
			}
		return s;
		}
	}

