import java.io.*;
class Stack
	{
	int stck[];
	int tos;
	Stack(int n)
		{
		tos=-1;
		stck=new int[n];
		}
	void push(int item)
		{
		if(tos==(stck.length-1))
			{
			full();
			}
		else
			{
			stck[++tos]=item;
			}
		}
	int pop()
		{
		if (tos>=0)
			{
			int u=stck[tos];
			tos--;
			return u;
			}
		else
			{
			empty();
			return-999999;
			}
		}
	void full()
		{
		if(tos==(stck.length-1))
			{
			System.out.println("Stack is full");
			}
		else
			{
			System.out.println("Stack is not full");
			}
		}
	void empty()
		{
		if(tos>=0)
			{
			System.out.println("Stack is not empty");
			}
		else
			{
			System.out.println("Stack is empty");
			}
		}
	}


class demoq11
	{
	public static void main(String args[])throws IOException
		{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter size of stack");
		int b=Integer.parseInt(br.readLine());
		Stack ob=new Stack(b);
		int f=0;
		while(f==0)
			{
			System.out.println("1------->Push");
			System.out.println("2------->Pop");
			System.out.println("3------->Full");
			System.out.println("4------->Empty");
			System.out.println("5------->Exit");
			int ch=Integer.parseInt(br.readLine());
			switch(ch)
				{
				case 1:
				System.out.println("Enter element");
				int k=Integer.parseInt(br.readLine());
				ob.push(k);
				System.out.println(k+" Entered in stack");
				break;
				case 2:
				int y=ob.pop();
				System.out.println(y+" Is popped from stack");
				break;
				case 3:
				ob.full();
				break;
				case 4:
				ob.empty();
				break;
				case 5:
				f=1;
				System.out.println("Invalid choice");
				break;
				}
			}
		}
	}
