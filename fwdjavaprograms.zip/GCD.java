package P1;
public class GCD
	{
	public int gcd(int n,int d)
		{
		int r=0;
		int a=n;
		int b=d;
		while(b!= 0)
			{
			r = a%b;
			a=b;
			b= r;
			}
		return a;
		}
	}

