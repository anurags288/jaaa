import java.io.*;
class matrix
	{
	int row;
	int col;
	int a[][];
	matrix()
		{
		row=0;
		col=0;
		}
	matrix(int r,int c)
		{
		row=r;
		col=c;
		a=new int[r][c];
		}
	void input()throws IOException
		{
		BufferedReader x=new BufferedReader(new InputStreamReader(System.in));
		for(int i=0;i<row;i++)
			{
			for(int j=0;j<col;j++)
				{
				System.out.println("\n Enter elements \n");
				a[i][j]=Integer.parseInt(x.readLine());
				}
			}
		}
	matrix addition(matrix m)
		{
		matrix q=new matrix(row,col);
		if((row==m.row)&&(col==m.col))
			{
			for(int i=0;i<row;i++)
				{
				for(int j=0;j<col;j++)
					{
					q.a[i][j]=a[i][j]+m.a[i][j];
					}
				}
			}
		else
			{
			System.out.println("\n Addition cannot be carried out \n");
			}
		return q;
		}
	matrix substraction(matrix m)
		{
		matrix q=new matrix(row,col);
		if((row==m.row)&&(col==m.col))
			{
			for(int i=0;i<row;i++)
				{
				for(int j=0;j<col;j++)
					{
					q.a[i][j]=a[i][j]-m.a[i][j];
					}
				}
			}
		else
			{
			System.out.println("\n Substraction cannot be carried out \n");
			}
		return q;
		}	
	matrix multiplication(matrix m)
		{
		matrix q=new matrix(row,m.col);
		if(col==m.row)
			{
			for(int i=0;i<row;i++)
				{
				for(int j=0;j<m.col;j++)
					{
					for(int k=0;k<col;k++)
						{
						q.a[i][j]=q.a[i][j]+(a[j][k]*m.a[k][j]);
						}
					}
				}
			}
		else
			{
			System.out.println("\n Multiplication cannot be carried out \n");
			}
		return q;
		}
	matrix transpose()
		{
		matrix q=new matrix(col,row);
		for(int i=0;i<row;i++)
			{
			for(int j=0;j<col;j++)
				{
				q.a[j][i]=a[i][j];
				}
			}
		return q;
		}
	int traceLeft()
		{
		int left=0;
		if(row==col)
			{
			for(int i=0;i<row;i++)
				{
				for(int j=0;j<col;j++)
					{
					if(i==j)
						{
						left=left+a[i][j];
						}
					}
				}
			}
		else
			{
			System.out.println("\n Cannot find diagonal,not a square matrix \n");
			}
		return left;
		}
	int traceRight()
		{
		int right=0;
		if(row==col)
			{
			for(int i=0;i<row;i++)
				{
				for(int j=0;j<col;j++)
					{
					if((i+j)==row)
						{
						right=right+a[i][j];
						}
					}
				}
			}
		else
			{
			System.out.println("\n Cannot find diagonal,not a square matrix \n");
			}
		return right;
		}
	void print()
		{
		System.out.println("\n Matrix is \n");
		for(int i=0;i<row;i++)
			{
			for(int j=0;j<col;j++)
				{
				System.out.print("\t"+a[i][j]+"\t");
				}
			System.out.println();
			}
		}
	}


class demoq10
	{
	public static void main(String[] args)throws IOException
		{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("\n Enter no of rows \n");
		int r=Integer.parseInt(br.readLine());
		System.out.println("\n Enter no of columns \n");
		int c=Integer.parseInt(br.readLine());
		matrix ob=new matrix(r,c);
		ob.input();
		int f=0;
		while(f==0)
			{
			System.out.println("\n 1-------->Addition \n");
			System.out.println("\n 2-------->Substraction \n");
			System.out.println("\n 3-------->Multiplication \n");
			System.out.println("\n 4-------->Transpose \n");
			System.out.println("\n 5-------->Trace of matrix \n");
			System.out.println("\n 6-------->Exit \n");
			System.out.println("\n Enter choice \n");
			int ch=Integer.parseInt(br.readLine());
			switch (ch)
				{
				case 1:
				System.out.println("\n Enter no of rows \n");
				int r1=Integer.parseInt(br.readLine());
				System.out.println("\n Enter no of columns \n");
				int c1=Integer.parseInt(br.readLine());
				matrix ob1=new matrix(r1,c1);
				ob1.input();
				matrix obj;
				obj=ob.addition(ob1);
				System.out.println("\n Addition is \n");
				obj.print();
				break;


				case 2:
				System.out.println("\n Enter no of rows \n");
				int r2=Integer.parseInt(br.readLine());
				System.out.println("\n Enter no of columns \n");
				int c2=Integer.parseInt(br.readLine());
				matrix ob2=new matrix(r2,c2);
				ob2.input();
				matrix obj2;
				obj2=ob.substraction(ob2);
				System.out.println("\n Subtraction is \n");
				obj2.print();
				break;


				case 3:
				System.out.println("\n Enter no of rows \n");
				int r3=Integer.parseInt(br.readLine());
				System.out.println("\n Enter no of columns \n");
				int c3=Integer.parseInt(br.readLine());
				matrix ob3=new matrix(r3,c3);
				ob3.input();
				matrix obj3;
				obj3=ob.multiplication(ob3);
				System.out.println("\n Addition is \n");
				obj3.print();
				break;


				case 4:
				matrix obj4;
				obj4=ob.transpose();
				System.out.println("\n Transpose is \n");
				obj4.print();
				break;
			
		
				case 5:
				int l=ob.traceLeft();
				int ri=ob.traceRight();
				System.out.println("\n Left diagonal is ="+l+"\n");
				System.out.println("\n Right diagonal is ="+ri+"\n");	
				break;
	

				case 6:
				System.out.println("\n Invalid choice \n");
				f=1;
				break;
				}
			}
		}
	}

				


	
